package pages;

public class TeacherManagementPage {
}
